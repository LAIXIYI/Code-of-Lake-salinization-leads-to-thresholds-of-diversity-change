Note:
In this part, we aim to assess the contribution of environmental variables to the species density (S), rarefied richness (Sn), evenness (SPIE) and the abundance of macroinvertebrates.
To ensure consistency with later analyses that explore thresholds (Figure2), we log10(x+1)-transformed S, Sn, SPIE, and abundance values, and log10-transforming salinity values (mg/L).