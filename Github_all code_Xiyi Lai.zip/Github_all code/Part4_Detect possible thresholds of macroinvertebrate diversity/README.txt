Note:
Open the 'Visualization of Figure 2' using Origin (https://www.originlab.com/);
