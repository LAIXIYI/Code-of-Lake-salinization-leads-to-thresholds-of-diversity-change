#Paper code_<Lake salinization leads to thresholds of diversity change>
#Author: Xiyi Lai
#Emali: laixiyi@mail.ynu.edu.cn

######Part1_Effect-controlled diversity calculation#####
# area-based rarefied richness (S)
# individual-based rarefied richness (S_n)
# a measure of evenness emphasis common species (S_PIE)  
# following 'iNEXT' terminology
#############################################
# LOAD R PACKAGES
rm(list = ls())
require(dplyr)
require(tidyr)
library(vegan)
library(readr)
library(rlang)
library(data.table)

# install_package('iNEXT') # 
library(iNEXT)

############################
# Set path and directories #
############################
# set your own workplace
work_dir <- setwd('D:/Rfile/Diversity1')
work_dir
# 1_file loading----
# first set working directory in Menu/Session/Set working directory/to Project
data_path <- paste0(work_dir, "/species_data1")
data_path

# Read all data file names
filenames <- list.files(data_path,pattern="*.csv*", full.names = F)
filenames

# Make list of study ids
filename_roots <- gsub(".csv","",filenames) # remove .csv from filenames
study_ids <- unique(filename_roots)
study_ids

# 2_Read in data----
n_files <- length(unique(study_ids))

data_out <- list()

for (i in 1:n_files){
  
  data_file <- paste(data_path,"/", study_ids[i], ".csv", sep ="")
  
  data_out[[i]] <- read.csv(data_file, header = TRUE, 
                            stringsAsFactors = F,
                            fileEncoding = "UTF-8-BOM")
}


# 3_calculate richness----
all_div_out <- list()

for (i in 1:n_files){
  
  gamma_tab <- data_out[[i]]
  
  gamma_tab[is.na(gamma_tab)] <- 0
  
  # combine lakeno and year into one column
  
  gamma_tab <- unite(gamma_tab,"lakeno",lakeno:year,sep = "")
  
  gamma_tab$lakeno <- as.character(gamma_tab$lakeno)
  
  class(gamma_tab) <- ("data.frame")
  
  # estimate reference n for rarefaction and extrapolations
  
  # abundance
  abundance <- rowSums(gamma_tab[,-c(1)])
  
  # observed richness
  s <- specnumber(gamma_tab[,-c(1)])
  
  # set a common N ( median value of abundance in all lakes)
  n_ref <- 1612
  
  # use iNEXT to calculate error
  # 1. transfer data.frame to list
  gamma_tab3 <- split(as.matrix(gamma_tab[,-1]), 1:length(gamma_tab$lakeno)) 
  
  # rename list names
  names(gamma_tab3) <- gamma_tab$lakeno
  
  #  calculated individual-based rarefied richness 
  out1 <- estimateD(gamma_tab3, q = c(0,2), # Sn(q = 0); Spie(q = 2)
                    datatype = "abundance", 
                    base="size",
                    level = n_ref) %>%
    select(1,4,6:8)
  
  out2 <- dplyr::rename(out1, 'group' = 'Assemblage',
                        "index" = "Order.q",
                        "LCI" = 'qD.LCL',
                        "UCI" = "qD.UCL")
  
  out2$index <- factor(out2$index, labels = c("Sn", "Spie"))
  
  
  # tranfer long dataframe to wide
  out3 <- gather(out2,key = "index2",value = "value",3:5) %>%
    unite(index,2:3,sep = "_") %>% 
    spread(key = 'index',value = "value") %>% 
    cbind(abundance) %>%
    cbind(s)
  out3 <- dplyr::rename(out3,"Sn" = "Sn_qD", "Spie" = "Spie_qD")
  
  
  # calculate area-based rarefied richness 
  # we set a common area of 0.3 m2, then multipled 0.3 to abundance and got a 
  # commom individual, then folled the step of individual-based rarefaction method
  n_ref_fixarea <- (abundance * 0.3) 
  
  ##########################################
  out <- list()
  for (j in 1:length(n_ref_fixarea)) {
    out5 <- estimateD(gamma_tab3[j], q = 0, 
                      datatype = "abundance", 
                      base="size",
                      level = n_ref_fixarea[j])
    out[[j]] <- out5
  }
  out5 <- bind_rows(out)
  
  out6 <- dplyr::rename(out5, 'group' = 'Assemblage',"index" = "Order.q",
                        "s_area" = "qD","s_area_LCI" = 'qD.LCL',
                        "s_area_UCI" = "qD.UCL") %>%
    select(1,2,6:8) %>%
    full_join(out3,by = "group")
  
  all_div_out[[i]] <- bind_rows(out6)
}


# transfer list into a dataframe, seperate lakeno and year
diversity <- bind_rows(all_div_out) %>%
  tidyr::separate(group,c("lakeno","year"),sep = -4) %>%
  distinct()  

diversity$year <- as.numeric(diversity$year)
setwd('D:/Rfile/Diversity1')###Confirm the save path again 
write.csv(diversity,"diversity_metrics.csv")


######Part2_Location of lakes used in the paper#####
# Fig1c ---Lake location 
library(ggplot2)
#clear Global Environment
rm(list=ls())
# 1.load world map
mapworld <- borders(database = "world", 
                    colour="#DDDFDE", 
                    fill = "#DDDFDE",
                    size = 0) #world map
mp_world <- ggplot() + mapworld  
# 2. load your data
setwd('D:/Rfile/Addition2/Map8.12')
data <- read.csv("Sites of lakes.CSV")
head(data)

# 3. added points to world map------
tiff("map.tiff",
     compression = "lzw",
     res = 900,
     width = 17,
     height = 9,
     units = "cm")

mp_world + geom_point(data = data, aes(x = long, 
                                       y = la,
                                       color = type),
                      size = 1.8,alpha = 0.5,shape = 16) +
  labs(x="Longtitude (°E)",y="Latitude (°N)") + 
  scale_color_manual(values = c("Freshwater" = "#4792CD", 
                                "Saline" = "#750E1F", 
                                "Brackish" = "#DE2037")) + # Specify colors for each category
  scale_x_continuous(breaks = c(-180,-120,-60,0,60,120,180)) +
  scale_y_continuous(breaks = c(-90,-60,-30,0,30,60,90)) +
  theme_bw() +
  theme(panel.background = element_rect(fill = "white"),
        legend.spacing.x = unit(0.03,"cm"),
        legend.position.inside = c(0.1,0.45),
        legend.background = element_blank(),
        legend.title = element_blank(),
        axis.title = element_text(size = 10),
        axis.text = element_text(size = 10))

dev.off()#Here you can export the map PDF and beautify it in an editor such as Adobe Illustrator

######Part3_Spearman correlation analysis and random forest model #####
##Spearman correlation analysis
rm(list=ls())
library(corrplot)
library(tidyverse)
library(reshape2)
library(ggplot2)
setwd('D:/Rfile/Addition2/Randomtest')
bio <- read.csv("diversity.csv")
envs <- read.csv("envs.csv")

# Calculate the Spearman correlation coefficient matrix
cor_matrix <- matrix(NA, nrow = ncol(bio), ncol = ncol(envs))
p_matrix <- matrix(NA, nrow = ncol(bio), ncol = ncol(envs))

rownames(cor_matrix) <- colnames(bio)
colnames(cor_matrix) <- colnames(envs)
rownames(p_matrix) <- colnames(bio)
colnames(p_matrix) <- colnames(envs)

# Cycle through the correlation coefficients and p-values
for (i in 1:ncol(bio)) {
  for (j in 1:ncol(envs)) {
    test <- cor.test(bio[[i]], envs[[j]], method = "spearman")
    cor_matrix[i, j] <- test$estimate
    p_matrix[i, j] <- test$p.value
  }
}

# Convert to long format for ggplot
cor_long <- melt(cor_matrix, varnames = c("BioVar", "EnvVar"), value.name = "cor")
p_long <- melt(p_matrix, varnames = c("BioVar", "EnvVar"), value.name = "p_value")

# Merging of data
cor_data <- left_join(cor_long, p_long, by = c("BioVar", "EnvVar"))

# Add significance asterisk
cor_data <- cor_data %>%
  mutate(signif = case_when(
    p_value <= 0.001 ~ "***",
    p_value <= 0.01  ~ "**",
    p_value <= 0.05  ~ "*",
    TRUE             ~ ""
  ))

P_cor <- ggplot(cor_data, aes(x = EnvVar, y = BioVar, fill = cor)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(
    low = "#3372AE", mid = "white", high = "#C04049", 
    midpoint = 0, limit = c(-1, 1), name = "Spearman\nCorrelation"
  ) +
  geom_text(aes(label = sprintf("%.2f%s", cor, signif)), size = 3, color = "black") +
  scale_x_discrete(position = "top") +
  theme_minimal() +
  theme(
    axis.text.x.top = element_text(angle = 0, hjust = 0.5, vjust = 0.5, size = 12),
    axis.text.y = element_text(size = 12),
    axis.text.x = element_blank(),
    axis.title = element_blank(),
    plot.caption = element_text(size = 10, hjust = 0)
  ) +
  labs(caption = "Significance: * p < 0.05, ** p < 0.01, *** p < 0.001") +
  coord_fixed()

P_cor


##Assess the contribution of environmental variables to diversity in random forest model
library(linkET)
#Request random forest functionality
args(random_forest)
#Perform random forest calculations
rf <- random_forest(bio, envs)
#check results
summary(rf)
rf$explained
rf$importance
rf$p
#The preservation of calculation results
write.csv(rf$explained,"explained.csv")
write.csv(rf$importance,"importance.csv")
write.csv(rf$p,"P_value.csv")
#Based on these results you can visualize the important values of different environmental variables
#I used origin2024 for the visualization. More details can be found on my GitHub site.
library(tidyverse)
library(viridis)
# transformed long format
rf_imp <- rf$importance
rf_imp$Variable <- rownames(rf_imp)
rf_long <- pivot_longer(rf_imp, -Variable, names_to = "Metric", values_to = "Importance")

# Organize explained data for later labeling
rf_exp <- rf$explained

P_rf <- ggplot(rf_long, aes(x = Variable, y = Importance, fill = Metric)) +
  geom_bar(stat = "identity", position = "dodge", color = NA) +
  scale_fill_manual(
    values = c(
      "HFP" = "#fbb4b9",  
      "Elevation" = "#b3cde3",  
      "Salinity" = "#ccebc5",  
      "AMT" = "#e0bbe4",  
      "AMP" = "#ffed6f",  
      "Aridity" = "#ffffcc",  
      "TP" = "#c2a5cf",  
      "Chla" = "#f1c6d7",  
      "Area" = "#d3d3d3",  
      "Depth" = "#a8d0d2"  
    )
  ) +
  labs(x = "Biodiversity Index", y = "Importance (%)", fill = "Environmental Variable") +
  theme_bw() +  
  theme(
    axis.text.x = element_text(angle = 0, hjust = 1, size = 12),
    axis.text.y = element_text(size = 12),
    axis.title = element_text(size = 14),
    legend.title = element_text(size = 13),
    legend.text = element_text(size = 12)
  ) +
  geom_text(data = rf_exp,
            aes(x = Inf, y = Inf, label = paste0(name, ": ", round(explained, 1), "%")),
            hjust = 1.05, vjust = 1.5, inherit.aes = FALSE,
            size = 4.5, color = "black",
            position = position_nudge(y = -5)) +
  guides(fill = guide_legend(title.position = "top", title.hjust = 0.5))


P_rf
library(patchwork)
final_plot <- P_cor / P_rf + plot_layout(heights = c(1, 1))
print(final_plot)#####Figure S1


#####Part4_Detect possible thresholds of macroinvertebrate diversity###
### Figure2 Thresholds in diversity
## 1 .Precise regression discontinuity analysis - calculation of tipping point
## The values of AIC, BIC, and GCV are calculated and used to evaluate the fit of the model
library(segmented)
library(ggplot2)
#Create data frame
#setwd('D:/your own pathway')
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$S
data_df <- data.frame(X, Y)
# ----Precise Regression Analysis
model_S <- segmented(lm(Y ~ X, data = data_df), seg.Z = ~X)
summary(model_S)
AIC(model_S)
BIC(model_S)
#Manual calculation of GCV values
residuals <- residuals(model_S)# Extracting the residuals
n <- nrow(data_df)# n size
# Effective degrees of freedom of the model
# Total Degrees of Freedom = 
# Degrees of Freedom of the Basic Linear Model + Breakpoint Degrees of Freedom
df_linear <- length(coefficients(model_S))
df_segments <- length(model_S$psi)
df <- df_linear + df_segments
# Calculate GCV value
mse_S <- mean(residuals^2)  # Mean Square Error of Residuals
gcv_S <- mse / (1 - df / n)^2

gcv_S

###Repeat the above steps####Sn
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$Sn
data_df <- data.frame(X, Y)
# ----Precise Regression Analysis
model_Sn <- segmented(lm(Y ~ X, data = data_df), seg.Z = ~X)
summary(model_Sn)
AIC(model_Sn)
BIC(model_Sn)
#Manual calculation of GCV values
residuals <- residuals(model_Sn)
n <- nrow(data_df)
df_linear <- length(coefficients(model_Sn))
df_segments <- length(model_Sn$psi)
df <- df_linear + df_segments
# Calculate GCV value
mse_Sn <- mean(residuals^2)  # Mean Square Error of Residuals
gcv_Sn <- mse_Sn / (1 - df / n)^2

gcv_Sn
###Repeat the above steps####SPIE
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$Spie
data_df <- data.frame(X, Y)
# ----Precise Regression Analysis
model_SPIE <- segmented(lm(Y ~ X, data = data_df), seg.Z = ~X)
summary(model_SPIE)
AIC(model_SPIE)
BIC(model_SPIE)
#Manual calculation of GCV values
residuals <- residuals(model_SPIE)
n <- nrow(data_df)
df_linear <- length(coefficients(model_SPIE))
df_segments <- length(model_SPIE$psi)
df <- df_linear + df_segments
# Calculate GCV value
mse_SPIE <- mean(residuals^2)  # Mean Square Error of Residuals
gcv_SPIE <- mse_SPIE / (1 - df / n)^2

gcv_SPIE

###Repeat the above steps####Abundance
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$Abundance
data_df <- data.frame(X, Y)
# ----Precise Regression Analysis
model_Ab <- segmented(lm(Y ~ X, data = data_df), seg.Z = ~X)
summary(model_Ab)
AIC(model_Ab)
BIC(model_Ab)
#Manual calculation of GCV values
residuals <- residuals(model_Ab)
n <- nrow(data_df)
df_linear <- length(coefficients(model_Ab))
df_segments <- length(model_Ab$psi)
df <- df_linear + df_segments
# Calculate GCV value
mse_Ab <- mean(residuals^2)  # Mean Square Error of Residuals
gcv_Ab <- mse_Ab / (1 - df / n)^2

gcv_Ab
# Figure 2 visualizations are available 
# in the supplementary ZIP file as an Origin Project file (.opju format).


## 2 .Generalized additive models also be used to detect thresholds
library(mgcv)
#####citation("mgcv")
#setwd('D:/your own pathway')
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$S
data_df <- data.frame(X, Y)
gam_model_S <- gam(Y ~ s(X), data = data_df)

summary(gam_model_S)###GCV in the summary
AIC(gam_model_S)
BIC(gam_model_S)

# Plot the GAM model fit curve and add the scatter of the original data
plot(gam_model_S, 
     rug = TRUE, 
     shade = TRUE, 
     main = "GAM Model with Scatter Plot", 
     seWithMean = TRUE,
     xlab = "Salinity log10(x) mg/L",  
     ylab = "Standardized effects"      
) ###Can be exported to PDF for further visual optimization
####Repeat the above code to calculate the GAM of Sn, SPIE, Abundance and record its AIC,BIC and GCV

## 3 .Linear model fitting
#setwd('D:/your own pathway')
df <- read.csv("diversity_threshold.csv")
X <- df$Salinity
Y <- df$S
data_df <- data.frame(X, Y)
model_line_S <- lm(Y ~ X, data = data_df)

summary(model_line_S)
AIC(model_line_S)
BIC(model_line_S)

# Calculate GCV value
residuals <- residuals(model_line_S)
n <- nrow(data_df)
df <- length(coefficients(model_line_S))
mse_line_S <- mean(residuals^2)
gcv_line_S <- mse_line_S / (1 - df / n)^2
gcv_line_S

####Repeat the above code to calculate the GAM of Sn, SPIE, Abundance and record its AIC,BIC and GCV

## 4 .Comparing the fitting performance of the different models above
#setwd('D:/your own pathway')
library(ggplot2)
library(dplyr)
library(tidyr)
data <- data.frame(
  Model = c("S-seg", "S-line", "S-gam", "Sn-seg", "Sn-line", "Sn-gam", 
            "SPIE-seg", "SPIE-line", "SPIE-gam", "Ab-seg", "Ab-line", "Ab-gam"),
  AIC = c(161.292, 279.13, 140.842, 193.618, 313.462, 175.522, 
          -162.717, -131.866, -200.806, 995.53, 1082.703, 999.163),
  BIC = c(183.932, 292.714, 186.078, 216.258, 327.046, 220.874, 
          -140.077, -118.282, -162.294, 1018.169, 1096.287, 1035.613),
  GCV = c(0.075, 0.088, 0.071, 0.078, 0.092, 0.075, 0.046, 0.048, 0.044, 
          0.252, 0.284, 0.252)
)

data_long <- data %>%
  pivot_longer(cols = c("AIC", "BIC", "GCV"), names_to = "Metric", values_to = "Value")
# AIC/BIC visualizations
p_IC <- ggplot(data_long[data_long$Metric %in% c("AIC", "BIC"), ], aes(x = Model, y = Value, color = Metric, group = Metric)) +
  geom_point(size = 4) +  
  geom_line() +  
  scale_color_manual(values = c("AIC" = "#3372AE", "BIC" = "#C04049")) +  
  labs(x = "", y = "Values") +  
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 12),  
    plot.title = element_text(hjust = 0.5),  
    axis.title = element_text(size = 14),   
    axis.text.y = element_text(size = 12)   
  )

print(p_IC)

# GCV visualizations
p_GCV <- ggplot(data_long[data_long$Metric == "GCV", ], aes(x = Model, y = Value, color = Metric, group = Metric)) +
  geom_point(size = 4) +  
  geom_line() +  
  scale_color_manual(values = c("GCV" = "#262626")) +  
  labs(x = "Different models", y = "Values") +  
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 12),  
    plot.title = element_text(hjust = 0.5),  
    axis.title = element_text(size = 14),  
    axis.text.y = element_text(size = 12)   
  )

print(p_GCV)
library(patchwork)
final_plot <- p_IC / p_GCV + plot_layout(heights = c(1, 1))
print(final_plot)#####Figure S3
ggsave("final_plot.pdf", width = 8, height = 5, device = cairo_pdf)

######Part5_Beta diversity analysis and relative abundance of various groups#####
##Step_1 Beta diversity calculations and decomposing Beta diversity
#Packages
library(ade4)
library(adegraphics)
library(adespatial)
library(vegan)
library(vegetarian)
library(FD)
library(taxize)
library(devtools) 
library(ggtern)
library(tidyverse)
#setwd('D:/your own pathway')
dat2 <- read.csv('Canada_trans.csv')
#Clean data, first column lakeno merged into row names, build full matrix
str(dat2)
# Set the first column to the row name
row.names(dat2) <- dat2[, 1]
# Delete the first column
dat2 <- dat2[, -1]
#### decomposing Beta
####quant=F, non-quantitative calculation, replacing all abundance data with 1/0 data, Baselga (2010)
benthos_BJ_Canada <- beta.div.comp(dat2, coef = "BJ", quant = FALSE)#Jaccard
benthos_BS_Canada <- beta.div.comp(dat2, coef = "BS", quant = FALSE)#Sørensen
###quant=T, quantitative calculation, abundance data, Baselga (2013)
benthos_BJ_CanadaDL <- beta.div.comp(dat2, coef = "BJ", quant = TRUE)#
benthos_BS_CanadaDL <- beta.div.comp(dat2, coef = "BS", quant = TRUE)#
#colnames() <- c("Nestedness", "Similarity", "Turnover")
benthos_BS_totalCanada<- cbind(benthos_BS_Canada$rich,
                               (1 - benthos_BS_Canada$D),
                               benthos_BS_Canada$repl)###Consolidated into 3 columns
benthos_BS_totalCanadaDL<- cbind(benthos_BS_CanadaDL$rich,
                               (1 - benthos_BS_CanadaDL$D),
                               benthos_BS_CanadaDL$repl)###Consolidated into 3 columns

##Save results
write.csv(benthos_BS_totalCanada,"benthos_BS_Canada.csv")
write.csv(benthos_BS_totalCanadaDL,"benthos_BS_CanadaDL.csv")
####Repeat the above steps for Russia and Tibet
#Step_2 Calculate the absolute salinity difference
library(dplyr)
#setwd('D:/your own pathway')
salinity_df <- read.csv("salinity_data_Cannda.csv")
#salinity_df <- read.csv("salinity_data_Russia.csv")
#salinity_df <- read.csv("salinity_data_Tibet.csv")
# View data frame structure
head(salinity_df)

# Create an empty matrix to store the absolute value of the salinity difference
n <- nrow(salinity_df)
salinity_diff_matrix <- matrix(0, n, n)

# Calculate the absolute value of the salinity difference between the two lakes
for (i in 1:n) {
  for (j in 1:n) {
    salinity_diff_matrix[i, j] <- abs(salinity_df$Salinity[i] - salinity_df$Salinity[j])
  }
}

# output result
str(salinity_diff_matrix)
write.csv(salinity_diff_matrix,"salinity_diff_matrix.csv")

# Convert the matrix to a vector, keeping only the lower triangular part
salinity_diff_vector <- salinity_diff_matrix[lower.tri(salinity_diff_matrix)]

# Check the length of the vector
length(salinity_diff_vector)
str(salinity_diff_vector)
write.csv(salinity_diff_vector,"salinity_diff_vector.csv")

#Step_3 Linear regression models
#######Figure3_relationship between beta diversity and salinity difference
library(ggplot2)
library(dplyr)
library(patchwork)
####Nestedness, simliarity, turnover ~ salinity diff_Based on BS method
#setwd('D:/your own pathway')
df <- read.csv('Nest_BS_df.csv')
data <- data.frame(Group = df$Type, X = df$Salinity_diff, Y = df$Nestedness)
# Fitting linear models#
data_A <- data[data$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data[data$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data[data$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)
######P1
P1 <- ggplot(data, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +
  geom_smooth(method = "lm", formula = y ~ x,
              se = TRUE, 
              linewidth = 1.5,
              alpha = 0.5) +
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +
  labs(x = "Salinity difference (g/L)", 
       y = "Nestedness") +
  scale_y_continuous(limits = c(-0.05, 1)) +  
  theme_classic() +
  theme(
    legend.position = "none",
    axis.title = element_text(size = 11),
    axis.text = element_text(size = 10),
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)
  )
P1
######################P2
df2 <- read.csv('Sim_BS_df.csv')
data2 <- data.frame(Group = df2$Type, X = df2$Salinity_diff, Y = df2$Similarity)

data_A <- data2[data2$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data2[data2$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data2[data2$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)

P2 <- ggplot(data2, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +  
  geom_smooth(method = "lm", formula = y ~ x,
              se = TRUE, 
              linewidth = 1.5,  
              alpha = 0.5) +    
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +  
  labs(title = "", 
       x = "Salinity difference (g/L)",
       y = "Similarity") +
  theme_classic() +  
  theme(
    legend.position = "none",  
    axis.title = element_text(size = 11),
    axis.text = element_text(size = 10), 
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)  
  )
P2

############P3
df3 <- read.csv('Turnover_BS_df.csv')
data3 <- data.frame(Group = df3$Type, X = df3$Salinity_diff, Y = df3$Turnover)

data_A <- data3[data3$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data3[data3$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data3[data3$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)

P3 <- ggplot(data3, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +  
  geom_smooth(method = "lm", formula = y ~ x, 
              se = TRUE, 
              linewidth = 1.5,  
              alpha = 0.5) +    
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +  
  labs(title = "", 
       x = "Salinity difference (g/L)",  
       y = "Turnover") +
  theme_classic() + 
  theme(
    axis.title = element_text(size = 11),   
    axis.text = element_text(size = 10),    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)  
  )
P3

#####################P4
#########BAS_based on percentage difference-based indices
df4 <- read.csv('Nest_BSDL_df.csv')
data4 <- data.frame(Group = df4$Type, X = df4$Salinity_diff, Y = df4$Nestedness)

data_A <- data4[data4$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data4[data4$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data4[data4$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)

P4 <- ggplot(data4, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +  
  geom_smooth(method = "lm", formula = y ~ x,
              se = TRUE, 
              linewidth = 1.5,  
              alpha = 0.5) +    
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +  
  labs(title = "", 
       x = "Salinity difference (g/L)",
       y = "Nestedness") +
  theme_classic() +  
  theme(
    legend.position = "none",  
    axis.title = element_text(size = 11),
    axis.text = element_text(size = 10), 
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)  
  )
P4

###########################P5
df5 <- read.csv('Sim_BSDL_df.csv')
data5 <- data.frame(Group = df5$Type, X = df5$Salinity_diff, Y = df5$Similarity)

data_A <- data5[data5$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data5[data5$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data5[data5$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)

P5 <- ggplot(data5, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +  
  geom_smooth(method = "lm", formula = y ~ x,
              se = TRUE, 
              linewidth = 1.5,  
              alpha = 0.5) +    
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +  
  labs(title = "", 
       x = "Salinity difference (g/L)",
       y = "Similarity") +
  theme_classic() +  
  theme(
    legend.position = "none",  
    axis.title = element_text(size = 11),
    axis.text = element_text(size = 10), 
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)  
  )
P5

###########################P6
df6 <- read.csv('Turnover_BSDL_df.csv')
data6 <- data.frame(Group = df6$Type, X = df6$Salinity_diff, Y = df6$Turnover)

data_A <- data6[data6$Group == "Tibet", ]
model_Tibet <- lm(Y ~ X, data = data_A)###step1
summary(model_Tibet)

data_B <- data6[data6$Group == "Canada", ]
model_Canada <- lm(Y ~ X, data = data_B)###step2
summary(model_Canada)

data_C <- data6[data6$Group == "Russia", ]
model_Russia <- lm(Y ~ X, data = data_C)###step3
summary(model_Russia)

P6 <- ggplot(data6, aes(x = X, y = Y, color = Group)) + 
  geom_point(size = 3, alpha = 0.4) +  
  geom_smooth(method = "lm", formula = y ~ x, 
              se = TRUE, 
              linewidth = 1.5,  
              alpha = 0.5) +    
  scale_color_manual(values = c("#4E79A7", "#A0CBE8", "#F28E2B", "#FFBE7D", "#59A14F")) +  
  labs(title = "", 
       x = "Salinity difference (g/L)",  
       y = "Turnover") +
  theme_classic() +  
  theme(
    axis.title = element_text(size = 11),   
    axis.text = element_text(size = 10),    
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5)  
  )
P6

# Merge all diagrams
combined_plot <- P1 + P2 + P3 + P4 + P5 + P6 + 
  plot_layout(ncol = 3) 
combined_plot
#Save the pdf and then modify it appropriately###Figure3
ggsave("final_plot.pdf", width = 8, height = 5, device = cairo_pdf)

#Relative abundance of various groups
library(ggplot2)
#This package (ggridges) is mainly used to draw mountain maps, 
#especially for time or space distribution visualization
library(ggridges)
library(reshape2)
library(ggsci)
#setwd('D:/your own pathway')
otu <- read.csv('Abundance.csv')
#Normalization of abundance
#Normalize, but do not center, columns 2 through 10 of the table
otu[2:ncol(otu)] <- scale(otu[2:ncol(otu)], center = FALSE)
#Turn wide data into long data
#The retained field is “Salinity”, after transformation, “variable” is the name of each column, 
#and “value” is the corresponding abundance value of each column
otu1 <- reshape2::melt(otu, id = 'Salinity') 
head(otu1)
#Reading group type
type <- read.csv('matrix_type.csv')
#Merge packet data and OTU data together
otu2 <- merge(otu1, type, by = 'variable') #Merge by column named 'variable'

#set color
peakcol = c("#164C78", "#A6A6A6","#9ECAE1") 
#The stat parameter indicates the way to do statistics on the sample points, 
# by default identity, which means an x corresponds to a y.
p2c <-  ggplot(otu2, aes(x = Salinity, y = variable, height = value, fill = type))+
  geom_ridgeline(stat="identity",scale=1,color='white',show.legend=T)+
  scale_fill_manual(values = peakcol,limits = c('Trophic group','Functional feeding group','Taxonomic group'))+
  theme_bw()#Setting the fill color
p2c
#Save the pdf for your specific needs
ggsave("p2c.pdf", width = 8, height = 5, device = cairo_pdf)