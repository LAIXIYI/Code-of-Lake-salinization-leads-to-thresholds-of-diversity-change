Note:
You should prepare a SAD (species abundance distribution) data. (_trans in files);

Step1: Use the Baselga partitioning framework (Baselga, 2010; Baselga, 2013) using both presence–absence and abundance-based data.
For presence–absence data, we used the Sørensen dissimilarity index (Sørensen, 1948) to partition overall beta-diversity into turnover and nestedness-resultant components following Baselga (2010). For abundance data, we used the percentage difference index to decompose beta-diversity into balanced variation in abundance (corresponding to turnover) and abundance gradients (corresponding to nestedness), as described by Baselga (2013).

Step2: Calculate the absolute salinity difference, all analysis in code.

Step3: Performe linear regression models to examine how beta-diversity and its components responded to increasing salinity difference within each region
